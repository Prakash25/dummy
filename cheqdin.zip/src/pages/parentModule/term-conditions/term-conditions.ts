import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the TermConditionsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-term-conditions',
  templateUrl: 'term-conditions.html',
})
export class TermConditionsPage {
  selectStud: boolean =false;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  selectAllTC() {

}
  ionViewDidLoad() {
    console.log('ionViewDidLoad TermConditionsPage');
  }

}
