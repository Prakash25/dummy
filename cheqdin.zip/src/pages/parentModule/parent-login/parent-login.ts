import {Component, OnInit} from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import {ForgotPasswordPage} from "../../CommonModule/forgot-password/forgot-password";
import {FormGroup, Validators, FormControl} from "@angular/forms";
import {Device} from "@ionic-native/device";
import {FCM} from "@ionic-native/fcm";
import {RestProvider} from "../../../providers/user-services/user-services";

/**
 * Generated class for the ParentLoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-parent-login',
  templateUrl: 'parent-login.html',
})
export class ParentLoginPage implements  OnInit{

  _ForgotPassword: any;
  _loginForm: FormGroup;
  _userData= {"emails":"","password":""};
  _active_user: boolean = false;
  _active_password: boolean =false;
  countries: string[];
  errorMessage: string;
 // private backend;

  constructor(public navCtrl: NavController, public navParams: NavParams, private device: Device, private fcm: FCM, public rest: RestProvider) {
    this._ForgotPassword= ForgotPasswordPage;
  }
  ngOnInit() {
    let EMAILPATTERN = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    this._loginForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.pattern(EMAILPATTERN)]),
      password: new FormControl('', [Validators.required])
    });
  }
  signup(){
    alert(this._loginForm.valid)
    let thiss =this;
     this._userData['platform'] =// this.device.platform;
    this._userData['device_type'] = this.device.platform;
    this._userData['device_uuid'] = this.device.uuid;
     console.log(this.device.platform);
    this.fcm.getToken().then(token => {
      console.log(token)
      this._userData['token'] = token;
      this.rest.getCountries(this._userData)
        .subscribe(
          countries => this.countries = countries,
          error =>  this.errorMessage = <any>error);
    }
      //this.backend.registerToken(token);
    );
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad ParentLoginPage');
  }

}
