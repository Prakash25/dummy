import { Component } from '@angular/core';
import {NavController, NavParams} from 'ionic-angular';
import {ParentLoginPage} from "../parentModule/parent-login/parent-login";
import {CentreLoginPage} from "../NurseryModule/centre-login/centre-login";
//import { TranslateService } from '@ngx-translate/core';

/**
 * Generated class for the LoginOpPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
//@IonicPage()
@Component({
  selector: 'page-login-op',
  templateUrl: 'login-op.html',
})
export class LoginOpPage {
  _ParentLogin: any;
  _CentreLogin: any;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this._ParentLogin = ParentLoginPage;
    this._CentreLogin = CentreLoginPage;
   // translate.setDefaultLang('en');
    //translate.use('en');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginOpPage');
  }

}
