import {Component, OnInit} from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import {FormGroup, Validators, FormControl} from "@angular/forms";
import {ForgotPasswordPage} from "../../CommonModule/forgot-password/forgot-password";

/**
 * Generated class for the CentreLoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-centre-login',
  templateUrl: 'centre-login.html',
})
export class CentreLoginPage implements OnInit{

  _ForgotPassword: any;
  _loginForm: FormGroup;
  _userData= {"userName":"","password":""};
  _active_user: boolean = false;
  _active_password: boolean =false;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this._ForgotPassword= ForgotPasswordPage;
  }
  ngOnInit() {
    this._loginForm = new FormGroup({
      userName: new FormControl('', [Validators.required]),
      password: new FormControl('', [Validators.required])
    });
  }
  signup(){
    alert(this._loginForm.valid)
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CentreLoginPage');
  }

}
