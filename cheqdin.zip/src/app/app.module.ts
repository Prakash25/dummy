import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import {LoginOpPage} from "../pages/login-op/login-op";
import {TranslateModule, TranslateLoader} from "@ngx-translate/core";
import {TranslateHttpLoader} from "@ngx-translate/http-loader";
import {HttpClient, HttpClientModule} from "@angular/common/http";
import { ApiProvider } from '../providers/api/api';
import {ParentLoginPage} from "../pages/parentModule/parent-login/parent-login";
import {CentreLoginPage} from "../pages/NurseryModule/centre-login/centre-login";
import {ForgotPasswordPage} from "../pages/CommonModule/forgot-password/forgot-password";
import {ReactiveFormsModule} from "@angular/forms";
import {TermConditionsPage} from "../pages/parentModule/term-conditions/term-conditions";
import {Device} from "@ionic-native/device";
import {FCM} from "@ionic-native/fcm";
import {RestProvider} from '../providers/user-services/user-services';

// The translate loader needs to know where to load i18n files
// in Ionic's static asset pipeline.
export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    ListPage,
    LoginOpPage,
    ParentLoginPage,
    TermConditionsPage,
    CentreLoginPage,
    ForgotPasswordPage
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [HttpClient]
      }
    }),
    IonicModule.forRoot(MyApp),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    ListPage,
    LoginOpPage,
    // ParentLogin Modules
    ParentLoginPage,
    TermConditionsPage,
    // CentreLogin Modules
    CentreLoginPage,
    // Common Modules
    ForgotPasswordPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    FCM,
    Device,
    RestProvider,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    ApiProvider
  ]
})
export class AppModule {}
